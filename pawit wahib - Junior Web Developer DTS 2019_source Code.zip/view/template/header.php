<?php session_start(); ?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>PSB SEKOLAH SWASTA | Tugas Akhir DTS 2019</title>
    <link rel="stylesheet" href="../../assets/css/bootstrap.min.css">
    <link href="../../assets/fontawesome/css/all.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.4.0/animate.min.css" integrity="sha256-KLTFyUm/U7eSNct2I+KNcZ5+O4WHsa83bK34m3uGWsU=" crossorigin="anonymous" />

    <style>
        .bg-kolom {
            background-image: url("../../assets/img/bg-info.png");
        }

        .bg-atas {
            background-image: url("../../assets/img/bg-atas.png");
            background-size: cover;
            background-repeat: no-repeat;
        }
    </style>
</head>

<body>