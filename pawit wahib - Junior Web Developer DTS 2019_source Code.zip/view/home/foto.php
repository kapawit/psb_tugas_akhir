<?php
include("../template/header.php");
include("../template/navbar.php");
?>
<!-- start main -->
<main role="main">
    <!-- Start Container -->
    <div class="container py-4 bg-dark">
        <div class="row">
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header">
                        ini header card
                    </div>
                    <div class="card-body">
                        card body
                    </div>
                    <div class="card-footer">
                        card footer
                    </div>
                </div>
            </div>
            <div class="col-md-4 bg-primary">col-2</div>
            <div class="col-md-4">col-2</div>
        </div>
    </div>
    <!-- Finish container -->
</main>
<!-- Finish main -->
<?php
include("../template/footer.php");
?>